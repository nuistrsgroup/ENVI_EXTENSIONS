MCTK
====
The MODIS Conversion Toolkit is an ENVI plugin that can handle every known MODIS product. It ingests the original HDF file and allows you to select the dataset(s) you want to work with. It includes support for swath projection and grid reprojection and comes with an API for large batch processing jobs.

Please click on the RELEASES button above or follow this link to download the plugin: https://github.com/dawhite/MCTK/releases
